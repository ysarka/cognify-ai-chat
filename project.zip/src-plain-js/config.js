export const OPENROUTER_KEY = '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';
